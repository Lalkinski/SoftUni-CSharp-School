﻿using _01.DefineAClassPerson;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main()
        {
            Person person = new Person();
            person.Name = "Mario";
            person.Age = 17;
        }
    }
}
